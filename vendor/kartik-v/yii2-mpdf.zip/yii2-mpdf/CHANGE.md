version 1.0.1
=============
**Date:** 11-Mar-2015

- (enh #12): New `tempPath` property to allow setting temporary folder for mpdf font data.
- (enh #13): Default mode setting for Asian Languages via `Pdf::MODE_ASIAN`.
- (enh #14): Initialize with default mPDF configuration options.

version 1.0.0
=============
**Date:** 03-Nov-2014

- Initial release.
- Set release to stable.
